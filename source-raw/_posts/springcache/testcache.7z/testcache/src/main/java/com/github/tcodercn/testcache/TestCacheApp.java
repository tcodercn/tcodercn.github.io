package com.github.tcodercn.testcache;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.ApplicationContext;

import com.github.tcodercn.testcache.no.NoCacheUserService;
import com.github.tcodercn.testcache.simple.SimpleCacheUserService;
import com.github.tcodercn.testcache.spring.SpringCacheUserService;

@SpringBootApplication
@EnableCaching
public class TestCacheApp implements CommandLineRunner {
    //
    private Logger log = LoggerFactory.getLogger(TestCacheApp.class);
    //
    @Autowired
    private ApplicationContext context;
    @Autowired
    private CacheManager cacheMgr;
    
    public static void main(String[] args) {
        SpringApplication.run(TestCacheApp.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        List<Class<? extends UserService>> svcTypeList = Arrays.asList(
                NoCacheUserService.class,
                SimpleCacheUserService.class,
                SpringCacheUserService.class
        );
        UserService userSvc = context.getBean(svcTypeList.get(2));
        
        // testDirect(userSvc, "I0001");
        // testDirect(userSvc, "K0001");
        
        // testExpire(userSvc, "I0001");
        
        testMultiThread(userSvc, "I0001");
    }

    private void testDirect(UserService userSvc, String userId) {
        String name;
        // 1
        name = userSvc.getNameFromId(userId);
        log.info("result: {} -> {}", userId, name);
        // 2
        name = userSvc.getNameFromId(userId);
        log.info("result: {} -> {}", userId, name);
        // 3
        name = userSvc.getNameFromId(userId);
        log.info("result: {} -> {}", userId, name);
    }

    private void testExpire(UserService userSvc, String userId) {
        String name;
        // 1
        name = userSvc.getNameFromId(userId);
        log.info("result: {} -> {}", userId, name);
        // 2
        name = userSvc.getNameFromId(userId);
        log.info("result: {} -> {}", userId, name);
        // sleep
        try {
            Thread.sleep(2200);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        // 3
        name = userSvc.getNameFromId(userId);
        log.info("result: {} -> {}", userId, name);
        // 4
        name = userSvc.getNameFromId(userId);
        log.info("result: {} -> {}", userId, name);
    }

    private static class VirtualUser extends Thread {
        // 入参
        private final UserService userSvc;
        private final String userId;
        private final CountDownLatch latch;
        
        // 停止标志
        public volatile boolean stopFlag = false;
        // 计数
        public int counter = 0;
        
        public VirtualUser(UserService userSvc, String userId, CountDownLatch latch) {
            this.userSvc = userSvc;
            this.userId = userId;
            this.latch = latch;
        }
        
        @Override
        public void run() {
            try {
                // 等待
                latch.await();
                // 循环执行
                while (true) {
                    // 测试
                    String name = userSvc.getNameFromId(userId);
                    // 累加
                    counter++;
                    // 暂停
                    Thread.sleep(0);
                    // 是否停止
                    if (stopFlag) {
                        break;
                    }
                }
            }
            catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
    
    private void testMultiThread(UserService userSvc, String userId) throws Exception {
        // 虚拟用户数
        final int VUSER_COUNT = 200;

        log.info("create thread ...");
        CountDownLatch latch = new CountDownLatch(1);
        List<VirtualUser> threadList = new ArrayList<>();
        for (int i = 0; i < VUSER_COUNT; i++) {
            VirtualUser thread = new VirtualUser(userSvc, userId, latch);
            thread.start();
            threadList.add(thread);
        }
        
        log.info("go ...");
        latch.countDown();

        Thread.sleep(5 * 1000);

        log.info("stop thread ...");
        for (VirtualUser thread : threadList) {
            thread.stopFlag = true;
        }
        
        int totalCount = 0;
        for (VirtualUser thread : threadList) {
            thread.join();
            totalCount += thread.counter;
        }
        
        log.info("all done, counter: {}", totalCount);
    }
}
