package com.github.tcodercn.testcache.spring;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.github.tcodercn.testcache.AbstractUserService;
import com.github.tcodercn.testcache.ext.ExtCacheable;

@Component
public class SpringCacheUserService extends AbstractUserService {
    @Override
    // @Cacheable(cacheNames="SpringCache")
    // @Cacheable(cacheNames="SpringCache", condition="#userId.startsWith('K')")
    // @Cacheable(cacheNames="SpringCache,2")
    // @Cacheable(cacheNames="SpringCache,1,-0.5", 
    //    keyGenerator="ExtKeyGenerator")
    @ExtCacheable
    public String getNameFromId(String userId) {
        return getNameFromDb(userId);
    }
}
