package com.github.tcodercn.testcache;

public interface UserService {
    public String getNameFromId(String userId);
}
