package com.github.tcodercn.testcache.ext;

import java.util.concurrent.TimeUnit;

import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.stereotype.Component;

import com.github.benmanes.caffeine.cache.CacheLoader;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.tcodercn.testcache.TestCacheApp;

@Component
public class ExtCacheManager extends CaffeineCacheManager {
    //
    private Logger log = LoggerFactory.getLogger(TestCacheApp.class);

    @Autowired
    private CacheConfig cacheConfig;
    
    @Override
    protected Cache createCaffeineCache(String name) {
        // 获取配置
        CacheItem cacheItem = cacheConfig.getCacheItem(name);
        long maxSize = cacheItem.getMaxSize();
        long cacheTime = cacheItem.getCacheTime();
        long refreshTime = cacheItem.getRefreshTime();
        // 缓存加载器
        CacheLoader<Object, Object> loader = new CacheLoader<Object, Object>() {
            @Override
            public @Nullable Object load(@NonNull Object key) throws Exception {
                log.info("refresh cache: {}", key);
                ExtKey extKey = (ExtKey) key;
                return extKey.invoke();
            }
        };
        // 创建缓存
        Caffeine<Object, Object> builder = Caffeine.newBuilder()
                .expireAfterWrite(cacheTime, TimeUnit.MILLISECONDS);
        if (maxSize > 0) {
            builder.maximumSize(maxSize);
        }
        if (refreshTime > 0) {
            // 提前刷新
            builder.refreshAfterWrite(refreshTime, TimeUnit.MILLISECONDS)
                   .executor(Runnable::run);
        }
        return new CaffeineCache(name, builder.build(loader));
    }
}
