package com.github.tcodercn.testcache.ext;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("ext.cache")
public class CacheConfig {
    private Map<String, String> cacheItemMap;

    public void setCacheItemMap(Map<String, String> cacheItemMap) {
        this.cacheItemMap = cacheItemMap;
    }
    
    public CacheItem getCacheItem(String cacheName) {
        // 配置值
        String cfgStr = cacheItemMap.get(cacheName);
        String[] items = cfgStr.split(",");
        long maxSize = Long.parseLong(items[0]);
        long cacheTime = 1000 * (long) Float.parseFloat(items[1]);
        long refreshTime = 1000 * (long) Float.parseFloat(items[2]);
        // 计算刷新时间：-1 + 5 = 4
        if (refreshTime != 0) {
            refreshTime += cacheTime;
        }
        // 返回
        return new CacheItem(maxSize, cacheTime, refreshTime);
    }
}
