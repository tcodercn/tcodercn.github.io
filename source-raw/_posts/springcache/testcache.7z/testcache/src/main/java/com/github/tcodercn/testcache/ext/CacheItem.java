package com.github.tcodercn.testcache.ext;

public class CacheItem {
    private final long maxSize;
    private final long cacheTime;
    private final long refreshTime;
    
    public CacheItem(long maxSize, long cacheTime, long refreshTime) {
        this.maxSize = maxSize;
        this.cacheTime = cacheTime;
        this.refreshTime = refreshTime;
    }
    
    public long getMaxSize() {
        return maxSize;
    }
    
    public long getCacheTime() {
        return cacheTime;
    }
    
    public long getRefreshTime() {
        return refreshTime;
    }
}
