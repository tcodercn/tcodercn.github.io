package com.github.tcodercn.testcache.no;

import org.springframework.stereotype.Component;

import com.github.tcodercn.testcache.AbstractUserService;

@Component
public class NoCacheUserService extends AbstractUserService {
    @Override
    public String getNameFromId(String userId) {
        return getNameFromDb(userId);
    }
}
