package com.github.tcodercn.testcache;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractUserService implements UserService {
    private Logger log = LoggerFactory.getLogger(getClass());
    
    protected String getNameFromDb(String userId) {
        log.info("db query: {}", userId);
        // 暂停
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        // 返回
        return "Name_" + userId;
    }
}
