package com.github.tcodercn.testcache.ext;

import java.util.Arrays;
import java.util.Collection;

import org.springframework.cache.CacheManager;
import org.springframework.cache.interceptor.AbstractCacheResolver;
import org.springframework.cache.interceptor.CacheOperationInvocationContext;
import org.springframework.stereotype.Component;

@Component("ExtCacheResolver")
public class ExtCacheResolver extends AbstractCacheResolver {
    public ExtCacheResolver(CacheManager cacheManager) {
        super(cacheManager);
    }
    
    @Override
    protected Collection<String> getCacheNames(CacheOperationInvocationContext<?> context) {
        // 使用类名作为缓存名称
        String cacheName = context.getTarget().getClass().getSimpleName();
        return Arrays.asList(cacheName);
    }
}
