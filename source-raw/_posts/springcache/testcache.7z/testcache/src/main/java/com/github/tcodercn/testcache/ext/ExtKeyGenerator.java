package com.github.tcodercn.testcache.ext;

import java.lang.reflect.Method;

import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.stereotype.Component;

@Component("ExtKeyGenerator")
public class ExtKeyGenerator implements KeyGenerator {
    @Override
    public Object generate(Object target, Method method, Object... params) {
        return new ExtKey(target, method, params);
    }
}
