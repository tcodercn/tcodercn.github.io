package com.github.tcodercn.testcache.ext;

import java.lang.reflect.Method;
import java.util.Arrays;

import org.springframework.util.StringUtils;

public class ExtKey {
    private final Object target;
    private final Method method;
    private final Object[] params;
    private final int hashCode;
    
    public ExtKey(Object target, Method method, Object... params) {
        this.target = target;
        this.method = method;
        // 复制参数
        this.params = new Object[params.length];
        System.arraycopy(params, 0, this.params, 0, params.length);
        // 计算hash
        this.hashCode = Arrays.deepHashCode(this.params);
    }
    
    public Object invoke() throws Exception {
        return this.method.invoke(target, params);
    }

    @Override
    public boolean equals(Object other) {
        return (this == other ||
                (other instanceof ExtKey && Arrays.deepEquals(this.params, ((ExtKey) other).params)));
    }

    @Override
    public final int hashCode() {
        return this.hashCode;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + " [" + StringUtils.arrayToCommaDelimitedString(this.params) + "]";
    }
}
